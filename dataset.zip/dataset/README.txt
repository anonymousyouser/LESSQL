To correctly assign the PK-FK constraints on the provided schemas, follow the instructions below.

1 - Create and dump all schemas in the MySQL DBMS
2 - In the 'constraints' directory, you will find all the constrains for a range of schemas. The file name states the last schema where the file is supposed to work, since a modification in the schema affects one or more tables and corresponding PK-FK constraints.
3 - With this in mind, if the file name is 'v2.sql', you should dump the constraints in all versions before (and including) database schema v2. In any version after v2, the user must dump the next constraints file (following the number order in the file name).